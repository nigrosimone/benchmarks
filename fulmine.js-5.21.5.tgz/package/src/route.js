/*
Copyright 2026 Nigro Simone

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

const { METHODS } = require("http");
const { NullObject } = require("./utils.js");

// how many handlers may run one after another before the stack is let go of. Express uses the
// same number for the same reason: a route with thousands of synchronous handlers would otherwise
// grow the call stack until it blows
const SYNC_LIMIT = 100;

/**
 * The handlers registered for one path, and the walk over them.
 *
 * Express exports this, and code that builds a route by hand uses it: `new Route(path)`, a handler
 * per verb, then `dispatch(req, res, done)`. It does no matching, only which verb a handler answers.
 */
class Route {
    /** What this route was registered for, kept for whoever reads it: matching happens before dispatch. @type {string} */
    path;

    /** @type {{method: string|undefined, handle: Function}[]} */
    stack = [];

    /** Which verbs have a handler, which is what an OPTIONS reply is built from. @type {Record<string, any>} */
    methods = new NullObject();

    /**
     * @param {string} path what this route was registered for
     */
    constructor(path) {
        this.path = path;
    }

    /**
     * Whether this route answers the verb, HEAD falling back to GET as it does over the wire.
     *
     * @param {string} method
     * @returns {boolean}
     */
    handlesMethod(method) {
        // all() answers every verb, registered or not, which is what express reads _all for
        if (this.methods._all) {
            return true;
        }
        const lowered = method.toLowerCase();
        return Boolean(this.methods[lowered] || (lowered === "head" && this.methods.get));
    }

    /**
     * The verbs this route answers, in upper case, HEAD included when GET is there.
     *
     * @returns {string[]}
     */
    _methods() {
        const methods = Object.keys(this.methods);
        if (this.methods.get && !this.methods.head) {
            methods.push("head");
        }
        return methods.map((method) => method.toUpperCase());
    }

    /**
     * Runs the handlers this request's verb reaches, one after another through next().
     *
     * @param {any} req a Request, or whatever a caller that built this Route by hand is serving
     * @param {any} res the matching response
     * @param {(err?: unknown) => void} done called when the route is finished with the request, with
     *   whatever error it ended on
     */
    dispatch(req, res, done) {
        let index = 0;
        let sync = 0;
        const stack = this.stack;
        if (stack.length === 0) {
            return done();
        }

        let method = String(req.method ?? "").toLowerCase();
        if (method === "head" && !this.methods.head) {
            method = "get";
        }
        req.route = this;

        /** @param {unknown} [err] */
        const next = (err) => {
            // next("route") leaves this route, and next("router") leaves whoever is running it
            if (err === "route") {
                return done();
            }
            if (err === "router") {
                return done(err);
            }
            if (index >= stack.length) {
                return done(err);
            }
            if (++sync > SYNC_LIMIT) {
                sync = 0;
                return setImmediate(next, err);
            }

            let layer;
            let matched = false;
            while (!matched && index < stack.length) {
                layer = stack[index++];
                matched = !layer.method || layer.method === method;
            }
            if (!matched) {
                return done(err);
            }

            const handle = /** @type {{handle: Function}} */ (layer).handle;
            // an error only reaches the four-argument handlers, and everything else only runs
            // while there is no error, which is the same rule ordinary dispatch follows
            if (err) {
                if (handle.length !== 4) {
                    return next(err);
                }
            } else if (handle.length === 4) {
                return next();
            }
            try {
                const out = err ? handle(err, req, res, next) : handle(req, res, next);
                // a rejected promise goes to next() as the error it carries, as express's Layer
                // does it. A bare rejection carries none and gets the one express invents. Thenable
                // too, which express deprecates but still waits for
                if (out && typeof out.then === "function") {
                    out.then(null, (/** @type {unknown} */ thrown) => next(thrown || new Error("Rejected promise")));
                }
            } catch (thrown) {
                next(thrown);
            }
            sync = 0;
        };

        next();
    }
}

/**
 * Refuses a handler that could never be called, worded as express words it.
 *
 * @param {string} method the verb this was registered for, for the message
 * @param {unknown[]} handlers
 */
function checkRouteHandlers(method, handlers) {
    for (const handle of handlers) {
        if (typeof handle !== "function") {
            const type = Object.prototype.toString.call(handle);
            throw new TypeError(`Route.${method}() requires a callback function but got a ${type}`);
        }
    }
}

// every verb, plus all(), registered the same way: flattened, checked, then pushed with the verb
// they answer. all() pushes handlers with no verb at all, which matches every request. Loose:
// the members are written here by name and not declared on the class
const prototype = /** @type {any} */ (Route.prototype);
for (const method of ["all", ...METHODS.map((verb) => verb.toLowerCase())]) {
    if (method !== "all" && typeof prototype[method] === "function") {
        continue;
    }
    prototype[method] = function (/** @type {unknown[]} */ ...handlers) {
        const flattened = handlers.flat(Infinity);
        checkRouteHandlers(method, flattened);
        // the check above threw on anything else
        for (const handle of /** @type {Function[]} */ (flattened)) {
            this.stack.push({ method: method === "all" ? undefined : method, handle });
            // express marks the route _all rather than naming every verb, and whoever reads
            // req.route.methods reads that key, so it is written the same way here
            this.methods[method === "all" ? "_all" : method] = true;
        }
        return this;
    };
}

module.exports = Route;
