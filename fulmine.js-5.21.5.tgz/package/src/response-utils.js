/*
Copyright 2024 dimden.dev
Copyright 2026 Nigro Simone

This file is derived from Ultimate Express and has been modified.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

const http = require("http");
const statuses = require("statuses");
const { EventEmitter } = require("events");

const outgoingMessage = new http.OutgoingMessage();
const symbols = Object.getOwnPropertySymbols(outgoingMessage);
// if a future node renames it, fall back to a private symbol rather than writing a property
// literally named "undefined", which is what indexing with undefined would do
const kOutHeaders = symbols.find((s) => s.toString() === "Symbol(kOutHeaders)") ?? Symbol("kOutHeaders");
// node's emitters tombstone a removed listener's slot instead of deleting it when this flag is set,
// which keeps _events in a stable shape. EventEmitter.init sets it and never runs for the lazily
// materialized response, so it is set by hand. A future rename degrades to the delete
const kShapeMode =
    Object.getOwnPropertySymbols(new EventEmitter()).find((s) => s.toString() === "Symbol(shapeMode)") ??
    Symbol("shapeMode");
// names setHeader has validated and lowercased, so the constant names middleware writes per
// request are one Map hit. Insert-only after validation, bounded; only setHeader may insert,
// the never-throwing readers have HEADER_KEYS below
const VALIDATED_HEADER_NAMES = new Map();
// lowercase names for the header readers, apart from the map above as nothing here is validated.
// A fresh lowercase key goes through the V8 runtime on res.headers: 76ns against 6 cached, and
// helmet's removeHeader("X-Powered-By") alone was 190us per thousand requests. Bounded too
/** @type {Map<string, string>} */
const HEADER_KEYS = new Map();

/**
 * The key a header lives under in res.headers, for the readers.
 *
 * @param {string} field the name as the caller wrote it
 * @returns {string}
 */
function headerKey(field) {
    let key = HEADER_KEYS.get(field);
    if (key === undefined) {
        key = field.toLowerCase();
        if (HEADER_KEYS.size < 512 && typeof field === "string") {
            HEADER_KEYS.set(field, key);
        }
    }
    return key;
}
// The names and values that recur on every response, kept as Buffers for the uWS crossing: a Buffer
// is memcpy'd as it is, a string pays a UTF-8 scan and copy per call. A header that is not here
// crosses as the string it was. Names must stay lowercase, as writeHeaders receives them. The
// casts are for the __proto__ key, which the type checker reads as a property
/** @type {Record<string, Buffer>} */
const HEADER_NAME_BUF = /** @type {any} */ ({ __proto__: null });
/** @type {Record<string, Buffer>} */
const HEADER_VALUE_BUF = /** @type {any} */ ({ __proto__: null });
for (const s of ["connection", "keep-alive", "content-type", "vary", "x-powered-by", "content-encoding"]) {
    HEADER_NAME_BUF[s] = Buffer.from(s);
}
for (const s of [
    "keep-alive",
    "timeout=10",
    "close",
    "Fulmine",
    "Accept-Encoding",
    "text/html; charset=utf-8",
    "text/plain; charset=utf-8",
    "application/json; charset=utf-8",
    "application/octet-stream",
    "gzip",
    "br",
    "deflate",
    "zstd",
    // res.set("Content-Type", x) stores false when the mime database knows nothing about x, the
    // way express does, and the lookup below turns that back into the bytes node writes for it
    "false"
]) {
    HEADER_VALUE_BUF[s] = Buffer.from(s);
}

// One status line per code, built on first use: the default path, with no custom reason phrase,
// paid a template string and a trim per request for a line that never changes. Bounded to real
// HTTP codes so a wild writeHead value cannot grow the array or flip it into dictionary mode.
const STATUS_LINES = /** @type {string[]} */ ([]);
/**
 * @param {number} code
 * @param {string|undefined} text an explicit reason phrase, which bypasses the cache
 * @returns {string} the uWS status line, e.g. "200 OK"
 */
function statusLine(code, text) {
    if (text === undefined && Number.isInteger(code) && code >= 100 && code <= 999) {
        return STATUS_LINES[code] ?? (STATUS_LINES[code] = code + " " + (statuses.message[code] ?? "unknown"));
    }
    return `${code} ${text ?? statuses.message[code] ?? "unknown"}`.trim();
}

/**
 * The TypeError node throws for a chunk that is not a string, a Buffer or a Uint8Array, worded as
 * node words it.
 *
 * @param {unknown} chunk what end() was handed, known here not to be a string or a Uint8Array
 * @returns {NodeJS.ErrnoException}
 */
function invalidChunkError(chunk) {
    let received;
    if (chunk === null) {
        received = "null";
    } else if (typeof chunk === "object" || typeof chunk === "function") {
        const name = /** @type {any} */ (chunk).constructor?.name;
        received = name ? `an instance of ${name}` : "an instance of Object";
    } else if (typeof chunk === "bigint") {
        received = `type bigint (${chunk}n)`;
    } else if (typeof chunk === "symbol") {
        received = `type symbol (${String(chunk)})`;
    } else {
        received = `type ${typeof chunk} (${chunk})`;
    }
    /** @type {NodeJS.ErrnoException} */
    const err = new TypeError(
        `The "chunk" argument must be of type string or an instance of Buffer or Uint8Array. Received ${received}`
    );
    err.code = "ERR_INVALID_ARG_TYPE";
    // as node: the bracketed name goes into the stack's first line, then err.name reads TypeError
    err.name = "TypeError [ERR_INVALID_ARG_TYPE]";
    void err.stack;
    delete (/** @type {Record<string, unknown>} */ (/** @type {unknown} */ (err)).name);
    return err;
}

module.exports = {
    kOutHeaders,
    kShapeMode,
    VALIDATED_HEADER_NAMES,
    headerKey,
    HEADER_NAME_BUF,
    HEADER_VALUE_BUF,
    statusLine,
    invalidChunkError
};
