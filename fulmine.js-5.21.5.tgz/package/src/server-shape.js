/*
Copyright 2026 Nigro Simone

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// What makes an application answer as an http.Server, for graceful shutdown libraries and
// connection trackers: the net.Server members added below, and `instanceof http.Server` taught
// through Symbol.hasInstance, since the prototype chain runs through Router. Nothing emits
// 'request', 'connection' or 'upgrade', there are no node sockets: socket.io wants app.uwsApp.

const http = require("http");
const net = require("net");

/** @typedef {import("./application.js").Application} Application */

// what marks an application, read by the instanceof hook below. A symbol, so no plain field name
// can be mistaken for it
const kIsApplication = Symbol.for("fulmine.application");

/**
 * Teaches `instanceof` that an application is a server, once per class. The original answer is
 * asked first and never overruled.
 *
 * @param {Function & {[kIsApplication]?: boolean}} klass http.Server or net.Server
 */
function acceptApplications(klass) {
    const previous = klass[Symbol.hasInstance];
    // already taught, which happens when two copies of this package share one process
    if (klass[kIsApplication] === true) {
        return;
    }
    Object.defineProperty(klass, Symbol.hasInstance, {
        /** @param {unknown} value @returns {boolean} */
        value: function (value) {
            if (previous.call(this, value)) {
                return true;
            }
            // an application is a function and a property read works on one. The guard is for the
            // primitives and nulls that reach any instanceof
            return value != null && /** @type {{[kIsApplication]?: unknown}} */ (value)[kIsApplication] === true;
        },
        configurable: true,
        writable: true
    });
    Object.defineProperty(klass, kIsApplication, { value: true, configurable: true });
}

acceptApplications(http.Server);
acceptApplications(net.Server);

/**
 * The net.Server members Express's API does not give, on the application prototype. Each one
 * answers for uWS, not for a node socket.
 *
 * @param {any} prototype Application.prototype, loose because the members are written here and not
 *   declared on the class
 */
function addServerMembers(prototype) {
    Object.defineProperty(prototype, kIsApplication, { value: true, configurable: true });

    /**
     * How many requests this application is serving right now. node counts sockets, there are none
     * here, and this is the number a graceful shutdown waits for. An idle keep-alive is not counted.
     *
     * @param {(err: Error|null, count: number) => void} callback
     */
    prototype.getConnections = function getConnections(callback) {
        let count = 0;
        for (let response = this._pending.head; response !== null; response = response._pendingNext) {
            count++;
        }
        // node answers this one asynchronously, and a caller written against it may rely on that
        process.nextTick(callback, null, count);
    };

    /**
     * A handle this does not own: uWS's loop keeps the process alive and a caller cannot unref it.
     * Both are no-ops returning the server, so a chain written against node's API keeps working.
     *
     * @this {Application}
     * @returns {Application}
     */
    prototype.ref = function ref() {
        return this;
    };

    /** @this {Application} @returns {Application} */
    prototype.unref = function unref() {
        return this;
    };

    /**
     * Registers the callback like node's does and remembers the value, which is all a caller can
     * observe. The timeout belongs to uWS and is set through uwsOptions.idleTimeout.
     *
     * @this {Application & {timeout?: number|undefined}}
     * @param {number} [msecs]
     * @param {() => void} [callback]
     * @returns {Application}
     */
    prototype.setTimeout = function setTimeout(msecs, callback) {
        this.timeout = msecs;
        if (callback) {
            this.on("timeout", callback);
        }
        return this;
    };

    // The numbers node's http.Server carries. Inert here, but declared rather than left undefined:
    // a library reads `server.keepAliveTimeout` to work out what it is talking to.
    for (const [name, value] of /** @type {[string, number|null][]} */ ([
        ["timeout", 0],
        ["keepAliveTimeout", 5000],
        ["headersTimeout", 60000],
        ["requestTimeout", 300000],
        ["maxHeadersCount", null],
        ["maxRequestsPerSocket", 0]
    ])) {
        Object.defineProperty(prototype, name, { value, writable: true, configurable: true, enumerable: false });
    }
}

module.exports = { addServerMembers, kIsApplication };
