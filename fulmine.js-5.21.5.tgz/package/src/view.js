/*
Copyright 2024 dimden.dev
Copyright 2026 Nigro Simone

This file is derived from Ultimate Express and has been modified.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

const path = require("path");
const fs = require("fs");
const { NullObject } = require("./utils.js");

module.exports = class View {
    /** The template name as render() was given it. @type {string} */
    name;

    /** A copy of the render options: defaultEngine, root and engines. @type {any} */
    options;

    /** @type {string|undefined} */
    defaultEngine;

    /** The extension, the default engine's when the name has none. @type {string} */
    ext;

    /** The views directory, or a list of them. @type {string|string[]} */
    root;

    /** @type {Function} */
    engine;

    /** The file resolved, undefined when no root holds it. @type {string|undefined} */
    path;

    /**
     * Resolves a template name to a file, so that render() has something to hand the engine. An
     * absolute name is taken as it stands; anything else is looked for under each configured root.
     *
     * @param {string} name template name, with or without its extension
     * @param {any} options defaultEngine, root and engines. Loosely typed on purpose: the
     *   constructor throws when what it needs is missing rather than checking each use
     */
    constructor(name, options) {
        this.name = name;
        this.options = options ? Object.assign({}, options) : new NullObject();
        this.defaultEngine = options.defaultEngine;
        this.ext = path.extname(name);
        this.root = options.root;

        if (!this.ext && !this.defaultEngine) {
            throw new Error("No default engine was specified and no extension was provided.");
        }

        let fileName = name;
        if (!this.ext) {
            // the throw above: no extension means there is a default engine
            const defaultEngine = /** @type {string} */ (this.defaultEngine);
            this.ext = defaultEngine[0] !== "." ? "." + defaultEngine : defaultEngine;

            fileName += this.ext;
        }

        if (!this.options.engines[this.ext]) {
            const mod = this.ext.slice(1);

            // default engine export
            const fn = require(mod).__express;

            if (typeof fn !== "function") {
                throw new Error('Module "' + mod + '" does not provide a view engine.');
            }

            this.options.engines[this.ext] = fn;
        }

        this.engine = this.options.engines[this.ext];
        if (path.isAbsolute(name)) {
            this.path = name;
            if (path.extname(name) === "") {
                this.path += this.ext;
            }
        } else {
            this.path = this.lookup(fileName);
        }
    }

    /**
     * The first configured root that holds this template, or undefined. `views` may be one
     * directory or a list, and the list is searched in order.
     *
     * @param {string} name template file name, relative to a root
     * @returns {string|undefined} absolute path to the file that exists
     */
    lookup(name) {
        let _path;
        const roots = /** @type {string[]} */ ([]).concat(this.root);
        for (let i = 0; i < roots.length && !_path; i++) {
            const root = roots[i];

            // resolve the path
            const loc = path.resolve(root, name);
            const dir = path.dirname(loc);
            const file = path.basename(loc);

            // resolve the file
            _path = this.resolve(dir, file);
        }
        return _path;
    }

    /**
     * Renders the template through its engine. The callback is always delivered on a later tick,
     * as Express does, even when the engine answered on the spot.
     *
     * @param {Record<string, any>} options locals and engine options, passed through
     * @param {Function} callback called with whatever the engine passed
     */
    render(options, callback) {
        let sync = true;
        // `this` is whatever the engine called onRender with, and it is forwarded untouched
        this.engine(
            this.path,
            options,
            /** @this {unknown} */ function onRender() {
                if (!sync) {
                    return callback.apply(this, arguments);
                }

                return process.nextTick(() => {
                    return callback.apply(this, arguments);
                });
            }
        );

        sync = false;
    }

    /**
     * The file a template name resolves to inside one directory, trying `<name>.<ext>` first and
     * then `<name>/index.<ext>`, which is how a template can be a directory with an index in it.
     *
     * @param {string} dir directory to look in
     * @param {string} file file name, with or without the extension
     * @returns {string|undefined} the path that exists, or undefined when neither does
     */
    resolve(dir, file) {
        const ext = this.ext;

        // <path>.<ext>
        let _path = path.join(dir, file);
        let stat = tryStat(_path);

        if (stat && stat.isFile()) {
            return _path;
        }

        // <path>/index.<ext>
        _path = path.join(dir, path.basename(file, ext), "index" + ext);
        stat = tryStat(_path);

        if (stat && stat.isFile()) {
            return _path;
        }
        return undefined;
    }
};

/**
 * fs.statSync that answers undefined instead of throwing, since a template that is not there is
 * the ordinary case while looking through several roots.
 *
 * @param {string} path
 * @returns {import("fs").Stats|undefined}
 */
function tryStat(path) {
    try {
        return fs.statSync(path);
    } catch (e) {
        return undefined;
    }
}
