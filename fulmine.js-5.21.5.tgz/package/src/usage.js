/*
Copyright 2026 Nigro Simone

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

"use strict";

const acorn = require("acorn");

/** @typedef {import("./router-utils.js").RouteEntry} RouteEntry */

// Marks a middleware the analysis may trust on a GET request without reading its source: the
// body parsers set it, whose prologue only reads body-framing headers and leaves a bodyless
// GET alone (and a GET that declares a body falls back to the full header copy).
const kGetSafe = Symbol("fulmine.getSafe");

// What a handler may do with `req` and still let the header copy be skipped: members whose reads
// never reach a header. Anything else, computed access included, keeps the copy. req.res and
// req.app are absent because they could reach headers through another object.
const REQ_OK = new Set(["query", "params", "body", "method", "path", "url", "baseUrl", "originalUrl", "route"]);

// Reading any of these needs the query string fetched: req.url and req.originalUrl carry it
const REQ_QUERY = new Set(["query", "url", "originalUrl"]);

// Writing any of these re-enters routing: dispatch treats a changed req.url as a rewrite and
// walks routes nobody analyzed, so an assignment is as disqualifying as an unknown call
const REQ_NO_WRITE = new Set(["url", "originalUrl", "path", "baseUrl", "method"]);

// What a handler may do with `res`: writing the response. Anything that negotiates against
// request headers (format, redirect, sendFile, jsonp) is deliberately absent.
const RES_OK = new Set([
    "json",
    "send",
    "end",
    "status",
    "sendStatus",
    "set",
    "setHeader",
    "header",
    "get",
    "type",
    "contentType",
    "append",
    "vary",
    "links",
    "locals",
    "statusCode",
    "writeHead",
    "headersSent",
    "finished",
    "cork"
]);

// what the analysis can say about one callback, as independent facts
const UNKNOWN = 1; // a shape the walk cannot vouch for: could do anything
const NEXT_PLAIN = 2; // calls next() bare: advances the chain, may fall off its end
const NEXT_ERROR = 4; // calls next(err): lands in the framework's own error answer
const QUERY = 8; // reads req.query, req.url or req.originalUrl

const verdicts = new WeakMap();

/**
 * What one callback provably does, as a mask of the facts above. The default is UNKNOWN: any shape
 * this walk does not understand, and any alias of req, res or next, could do anything.
 *
 * @param {Function & {[kGetSafe]?: boolean}} fn
 * @returns {number}
 */
function callbackUsage(fn) {
    if (fn[kGetSafe]) {
        // the body parsers: they advance the chain and read nothing a skip would miss
        return NEXT_PLAIN;
    }
    let verdict = verdicts.get(fn);
    if (verdict === undefined) {
        verdict = analyze(fn);
        verdicts.set(fn, verdict);
    }
    return verdict;
}

/** @param {Function} fn @returns {number} */
function analyze(fn) {
    // toString is application-controlled and may throw or answer anything: unreadable is unknown
    let code;
    try {
        code = String(fn.toString());
    } catch {
        return UNKNOWN;
    }
    if (code.startsWith("function") || code.startsWith("async function")) {
        code = code.replace(/function *\(/, "function __cb(");
    }
    let tree;
    try {
        tree = acorn.parse(code, { ecmaVersion: "latest" });
    } catch {
        // class methods and native functions do not parse alone, and unread code is unknown code
        return UNKNOWN;
    }
    let root = /** @type {import("acorn").AnyNode} */ (tree.body[0]);
    if (!root) {
        return UNKNOWN;
    }
    if (root.type === "ExpressionStatement") {
        root = root.expression;
    }
    if (
        root.type !== "FunctionDeclaration" &&
        root.type !== "ArrowFunctionExpression" &&
        root.type !== "FunctionExpression"
    ) {
        return UNKNOWN;
    }

    // checked by the loop below, which answers UNKNOWN for anything else
    const params = /** @type {import("acorn").Identifier[]} */ (root.params);
    // rest or destructured parameters alias the objects somewhere the walk cannot follow
    for (const p of params) {
        if (p.type !== "Identifier") {
            return UNKNOWN;
        }
    }
    const reqName = params[0] ? params[0].name : null;
    const resName = params[1] ? params[1].name : null;
    const nextName = params[2] ? params[2].name : null;

    // Every appearance of the three names is judged, nested functions included. An inner binding
    // that shadows one only makes this stricter, so no scope tracking is needed.
    let mask = 0;
    walk(root.body, null, (node, parent) => {
        if (mask & UNKNOWN) {
            return;
        }
        // a member read off what a call returned: res.status(200).sendFile() is a sendFile on res,
        // every chainable method returns res itself, so it is judged as one. Reading it off the
        // call had let sendFile and redirect through, and a Range or an Accept then went unread
        if (
            node.type === "MemberExpression" &&
            node.object.type === "CallExpression" &&
            resName !== null &&
            chainRoot(node.object) === resName
        ) {
            if (node.computed || !RES_OK.has(node.property.name)) {
                mask |= UNKNOWN;
            }
            return;
        }
        if (node.type === "MemberExpression" && !node.computed && node.object.type === "Identifier") {
            const owner = node.object.name;
            if (owner !== reqName) {
                return;
            }
            const member = node.property.name;
            if (REQ_QUERY.has(member)) {
                mask |= QUERY;
            }
            // an assignment, an update or a delete on the routing members re-enters dispatch
            if (
                REQ_NO_WRITE.has(member) &&
                parent &&
                ((parent.type === "AssignmentExpression" && parent.left === node) ||
                    (parent.type === "UpdateExpression" && parent.argument === node) ||
                    (parent.type === "UnaryExpression" && parent.operator === "delete" && parent.argument === node))
            ) {
                mask |= UNKNOWN;
            }
            return;
        }
        if (node.type !== "Identifier") {
            return;
        }
        const name = node.name;
        if (name === "eval" || name === "arguments") {
            mask |= UNKNOWN;
            return;
        }
        if (name !== reqName && name !== resName && name !== nextName) {
            return;
        }
        // being renamed inside a member expression (req.query's `query`) is not a use
        if (parent && parent.type === "MemberExpression" && parent.property === node && !parent.computed) {
            return;
        }
        // a redeclaration as an inner parameter or variable name is not a use either
        if (
            parent &&
            (((parent.type === "FunctionDeclaration" ||
                parent.type === "FunctionExpression" ||
                parent.type === "ArrowFunctionExpression") &&
                parent.params.includes(node)) ||
                (parent.type === "VariableDeclarator" && parent.id === node) ||
                (parent.type === "Property" && parent.key === node && !parent.computed))
        ) {
            return;
        }
        if (name === nextName) {
            // a direct next() call only, with an argument that cannot be the string "route"
            if (!parent || parent.type !== "CallExpression" || parent.callee !== node) {
                mask |= UNKNOWN;
                return;
            }
            const args = parent.arguments;
            if (args.length === 0) {
                mask |= NEXT_PLAIN;
                return;
            }
            const arg = args[0];
            if (
                args.length > 1 ||
                (arg.type !== "NewExpression" &&
                    arg.type !== "ObjectExpression" &&
                    !(arg.type === "Literal" && typeof arg.value !== "string"))
            ) {
                mask |= UNKNOWN;
                return;
            }
            mask |= NEXT_ERROR;
            return;
        }
        if (!parent || parent.type !== "MemberExpression" || parent.object !== node || parent.computed) {
            mask |= UNKNOWN;
            return;
        }
        const member = parent.property.name;
        if (name === reqName ? !REQ_OK.has(member) : !RES_OK.has(member)) {
            mask |= UNKNOWN;
        }
    });
    return mask;
}

/**
 * The identifier a chain of members and calls starts from: res for res.status(200).sendFile().
 *
 * @param {any} node
 * @returns {string|null} null when the chain does not start from a plain identifier
 */
function chainRoot(node) {
    while (node) {
        if (node.type === "MemberExpression") {
            node = node.object;
        } else if (node.type === "CallExpression") {
            node = node.callee;
        } else {
            return node.type === "Identifier" ? node.name : null;
        }
    }
    return null;
}

/**
 * Walks every node by key, handing each its parent.
 *
 * @param {any} node
 * @param {any} parent null at the root
 * @param {(node: any, parent: any) => void} visit
 */
function walk(node, parent, visit) {
    if (!node || typeof node.type !== "string") {
        return;
    }
    visit(node, parent);
    for (const key in node) {
        if (key === "type" || key === "start" || key === "end") {
            continue;
        }
        const value = node[key];
        if (Array.isArray(value)) {
            for (const item of value) {
                if (item && typeof item.type === "string") {
                    walk(item, node, visit);
                }
            }
        } else if (value && typeof value.type === "string") {
            walk(value, node, visit);
        }
    }
}

/**
 * What a native route's whole chain provably never does, so the request constructor may skip it:
 * skipHeaders the header copy, skipQuery the query fetch. A bare next() in the terminal route
 * passes only when no later route could catch the fall-through, the 404 reads the path alone.
 *
 * @param {RouteEntry[]} chain the routes the native handler runs, this route last
 * @param {boolean} allowTerminalNext whether a fall-through past the chain lands only in the 404
 * @returns {{skipHeaders: boolean, skipQuery: boolean}}
 */
function chainUsage(chain, allowTerminalNext) {
    const none = { skipHeaders: false, skipQuery: false };
    let query = false;
    for (let i = 0; i < chain.length; i++) {
        const entry = chain[i];
        const callbacks = entry.callbacks;
        if (!Array.isArray(callbacks)) {
            return none;
        }
        const terminal = i === chain.length - 1;
        for (let j = 0; j < callbacks.length; j++) {
            const cb = callbacks[j];
            if (typeof cb !== "function") {
                return none;
            }
            const mask = callbackUsage(cb);
            // a bare next() leaves the chain only from the route's last callback: from one in
            // front of it, the step lands on the next callback of the same route, judged here too
            const last = terminal && j === callbacks.length - 1;
            if (mask & UNKNOWN || (mask & NEXT_PLAIN && last && !allowTerminalNext)) {
                return none;
            }
            if (mask & QUERY) {
                query = true;
            }
        }
        // a param callback runs code this walk never saw
        if (entry.paramCallbacks && entry.paramCallbacks.size > 0) {
            return none;
        }
    }
    return { skipHeaders: true, skipQuery: !query };
}

module.exports = { chainUsage, callbackUsage, kGetSafe, UNKNOWN, NEXT_PLAIN, NEXT_ERROR, QUERY };
